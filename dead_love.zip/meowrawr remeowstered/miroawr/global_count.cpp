#include "global_count.h"

void game_event::on_hurt(IGameEvent * Event)
{
	if (!Event)
		global_count::didhit = false;

	if (!strcmp(Event->GetName(), "player_hurt"))
	{
		int deadfag = Event->GetInt("userid");
		int attackingfag = Event->GetInt("attacker");
		if (Interfaces::Engine->GetPlayerForUserID(attackingfag) == Interfaces::Engine->GetLocalPlayer())
		{
			global_count::didhit = true;
			global_count::on_fire = true;
		}
	}
}
