#pragma once
#include "Hooks.h"
#include "Interfaces.h"
#include "SDK.h"
#include "Hacks.h"

//void knife_bot(CUserCmd* cmd);