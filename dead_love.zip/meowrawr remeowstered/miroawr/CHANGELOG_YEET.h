#pragma once
/*
Mirror Remastered by Faxzee and FreaK

[MENU]
- Changed control style
- Changed fonts
- Added background darkness effect to the tabs when selected
- Added new colour boxes
- Added the following options for the top bar: Static (classic, still customiseable), Fade and Animated
- Added new watermark
- Re-organised Visual Misc and Colour Tab

[RAGE AIMBOT]
- Added multipoint option and slider
- Added pointscale option and slider
- Added an option for previously always on engine prediction
- Added extrapolation
- Added quickstop
- Added "Automatic NoSpread" for Pitch Adjustment
- Reworked the "FreaK - Prediction" and "Alternative" resolver.

[LEGIT AIMBOT]
- Removed "OnKey" option as it never worked
- Reworked "Default" Resolver
- Added "Alternative" Resolver (this is the "Prediction" from the rage aimbot)

[VISUALS]
- Removed "Text" Health option
- Changed Fonts in all of the ESP
- Changed overall placement of info in the ESP
- Changed damage logs
- Changed Hand / Weapon Chams
- Re-added glow, now done in DPSE to stop flickering
- Added colour to the damage logs when you get a headshot (menu control colour)
- Added "Real/LBY Delta" and "BackUp AA" indicators to the Local Info
- Added Glow Opacity
- Added Local Player Glow (pulse)
- Added Weapon Icon ESP
- Added Ammo Bar
- Added offscreen ESP
- Added Local Chams
- Added new options to Hand / Weapon Chams
- Reworked Sky Colour Modulation. Toggle it in the colour tab and set it to the desired colour then hit " Force Update"
- Changed Autowall Crosshair. It is now a dot which will go from Red to Blue if you can shoot through a surface
- Added "Standard", "Colour", "Rainbow" and "Rainbow Rotate" to the Spread crosshair
- Added Spread Crosshair size
- Added "Remove Zoom"
- Changed Manual AA Indicator from Text to Arrows
- Added Backtrack Chams (colour tab)
- Added Draw Lag Compensation (colour tab)

[MISC]
- Fixed a bug where you could toggle Backwards AA with "FaceIt Server" restriction
- Added "Unrestricted" safety mode
- Added Circle Strafe and custom Key
- Added a Third Person Ranges lider
- Added Debug Multipoint. Will draw the primary points in the aimbot.
- Added Fake Angle Ghost
- Added "Enable Experimental Features" for some unnamed and secret features hidden throughout the cheat, mostly rage and AA related.
- Added Radar

[ANTI-AIM]
- Added Fake Down Pitch
- Reworked Real Yaws. The list is now: Static, Jitter, 180Z, Manual Static, Manual Jitter, Lowerbody, Random Lowerbody and Freestanding.
- Reworked Fake Yaws. The list is now: Opposite, Jitter, Random Lowerbody, Half Spin, Random, Magic
- Reworked the "Builder 1" subtab. It now consists of sliders to alter the ranges or Real Standing and Moving Jitter, Lowerbody, and respective fakes.
- Added a mistery feature toggled along side the "Anti LBY" and Experimental options
- Added "Freestanding / Adaptive" to the Backup Anti Aims
- Added Fakelag while Standing
- Added Break Lag Compensation
- Added Fakelag Spike. Options: While Shooting, On Land
- Added Fakewalk Slowdown
- Reworked Fakewalk

[COLOURS]
- Reworked colour selection for almost all ESP
- Added Spread Crosshair Color
- Added Sky colour change option.

[CFGS]
- Reworked CFG saving
- You can now name, add, remove then save or load your own CFG
- CFGS are now saved in the csgo folder in a new dedicated file. ( steamapps/common/Counter-Strike Global Offensive/miroawr/cfg )

[OTHER]
- Pasted this stupid shit i wrote in 10 minutes into a file in the source because you know people are still gonna bitch about no changelogs despite being
too stupid to look.
*/