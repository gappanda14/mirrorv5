#include "Resolver.h"
#include "Ragebot.h"
#include "Hooks.h"
#include "RenderManager.h"
#include "edge.h"
#include "LagCompensation2.h"
#include "laggycompensation.h"
#include "global_count.h"
#include "edge.h"
#include "Autowall.h"
#ifdef NDEBUG
#define XorStr( s ) ( XorCompileTime::XorString< sizeof( s ) - 1, __COUNTER__ >( s, std::make_index_sequence< sizeof( s ) - 1>() ).decrypt() )
#else
#define XorStr( s ) ( s )
#endif

namespace global_count
{
	int hits[65] = { 0.f };
	int shots_fired[65] = { 0.f };

	bool didhit;
	bool on_fire;
}

void calculate_angle(Vector src, Vector dst, Vector &angles)
{
	Vector delta = src - dst;
	vec_t hyp = delta.Length2D();
	angles.y = (atan(delta.y / delta.x) * 57.295779513082f);
	angles.x = (atan(delta.z / hyp) * 57.295779513082f);
	angles[2] = 0.0f;
	if (delta.x >= 0.0) angles.y += 180.0f;
}

inline float RandomFloat(float min, float max)
{
	static auto fn = (decltype(&RandomFloat))(GetProcAddress(GetModuleHandle("vstdlib.dll"), "RandomFloat"));
	return fn(min, max);
}
void resolver_setup::preso(IClientEntity * pEntity)
{
	switch (Options::Menu.RageBotTab.preso.GetIndex())
	{
	case 1:
	{
		pEntity->GetEyeAnglesXY()->x = 89;
	}
	break;
	case 2:
	{
		pEntity->GetEyeAnglesXY()->x = -89;
	}
	break;
	case 3:
	{
		pEntity->GetEyeAnglesXY()->x = 0;
	}
	break;
	case 4:
	{
		float last_simtime[64] = { 0.f };
		float stored_pitch_1[64] = { 0.f };
		float stored_pitch_2[64] = { 0.f };

		const auto local = hackManager.pLocal();
		if (!local) return;

		for (auto i = 0; i < Interfaces::Engine->GetMaxClients(); ++i)
		{
			CMBacktracking* backtrack;
			const auto player = const_cast <IClientEntity*>(Interfaces::EntList->GetClientEntity(i));

			if (!player || local == player || player->GetTeamNum() == local->GetTeamNum() || player->IsImmune() || player->IsDormant())
			{
				last_simtime[i] = 0.f;
				stored_pitch_1[i] = 0.f;
				stored_pitch_2[i] = 0.f;
				continue;
			}

			auto is_legit = false;

			const auto eye = player->GetEyeAnglesXY();
			const auto sim = player->GetSimulationTime();

			if (sim - last_simtime[i] >= 1)
			{
				if (sim - last_simtime[i] == 1)
				{
					is_legit = true;
				}
				last_simtime[i] = sim;
			}

			int missed[65];
			missed[i] = global_count::shots_fired[i] - global_count::hits[i];
			while (missed[i] > 4) missed[i] -= 4;
			while (missed[i] < 0) missed[i] += 4;

			if (!is_legit)
			{
				if (player->GetVelocity().Length2D() > 0.1)
				{
					stored_pitch_1[i] = eye->x;
				}
				else
					stored_pitch_2[i] = eye->x;
			}

			auto pitch = 0.f;

			if (GetAsyncKeyState(Options::Menu.RageBotTab.OverrideKey.GetKey()))
			{
				pitch = 89.f;
			}
			else
			{
				if (stored_pitch_1[i] - stored_pitch_2[i] > 15)
				{
					switch (missed[i])
					{
					case 0:
						pitch = stored_pitch_1[i];
						break;
					case 1:
						pitch = stored_pitch_2[i];
						break;
					case 2:
						pitch = eye->x;
						break;
					case 3:
						pitch = stored_pitch_1[i];
						break;
					case 4:
						pitch = stored_pitch_2[i];
						break;
					}
				}
				else
				{
					pitch = 89.f;
				}
			}
			player->GetEyeAnglesXY()->x = pitch;
		}
	}
	break;
	case 5:
	{
		float last_simtime[64] = { 0.f };
		float last_pitch[64] = { 0.f };
		float difference[64] = { 0.f };

		bool did_change[64] = { false };

		const auto local = hackManager.pLocal();
		if (!local) return;

		for (auto i = 0; i < Interfaces::Engine->GetMaxClients(); ++i)
		{
			const auto player = const_cast <IClientEntity*>(Interfaces::EntList->GetClientEntity(i));
			if (!player || local == player || player->GetTeamNum() == local->GetTeamNum() || player->IsImmune() || player->IsDormant())
			{
				last_simtime[i] = 0.f;
				last_pitch[i] = 0.f;
				difference[i] = 0.f;
				did_change[i] = false;
				continue;
			}

			const auto eye = player->GetEyeAnglesXY();
			const auto sim = player->GetSimulationTime();

			int missed[64];
			missed[i] = global_count::shots_fired[i] - global_count::hits[i];
			while (missed[i] > 3) missed[i] -= 3;
			while (missed[i] < 3) missed[i] += 3;

			if (last_pitch[i] != eye->x)
			{
				did_change[i] = true;
				if (fabsf(eye->x - last_pitch[i]) > 88 && fabsf(eye->x - last_pitch[i]) < 160)
					difference[i] = 89.0;
				else if (fabsf(eye->x - last_pitch[i]) > 89)
					difference[i] = 178.0;
				else
					difference[i] = eye->x - last_pitch[i];

			}

			auto angle = 0.f;

			if (eye->x >= 89)
			{
				switch (missed[i])
				{
				case 0: angle = 89;
					break;
				case 1: angle = -89;
					break;
				case 2: angle = -eye->x;
				}
			}
			else if (eye->x >= 89)
			{
				switch (missed[i])
				{
				case 0: angle = -89;
					break;
				case 1: angle = 89;
					break;
				case 2: angle = -eye->x;
				}
			}
			else
			{
				switch (missed[i])
				{
				case 0: angle = -89;
					break;
				case 1: angle = 0;
					break;
				case 2: angle = 89;
				}
			}
			player->GetEyeAnglesXY()->x = angle;

		}
	}
	break;
	}



}

player_info_t GetInfo2(int Index) {
	player_info_t Info;
	Interfaces::Engine->GetPlayerInfo(Index, &Info);
	return Info;
}

static int GetSequenceActivity(IClientEntity* pEntity, int sequence)
{
	const model_t* pModel = pEntity->GetModel();
	if (!pModel)
		return 0;

	auto hdr = Interfaces::ModelInfo->GetStudiomodel(pEntity->GetModel());

	if (!hdr)
		return -1;

	static auto get_sequence_activity = reinterpret_cast<int(__fastcall*)(void*, studiohdr_t*, int)>(Utilities::Memory::FindPatternV2("client_panorama.dll", "55 8B EC 83 7D 08 FF 56 8B F1 74 3D"));

	return get_sequence_activity(pEntity, hdr, sequence);
}

float NormalizeFloatToAngle(float input)
{
	for (auto i = 0; i < 3; i++) {
		while (input < -180.0f) input += 360.0f;
		while (input > 180.0f) input -= 360.0f;
	}
	return input;
}

float override_yaw(IClientEntity* player, IClientEntity* local) {
	Vector eye_pos, pos_enemy;
	CalcAngle(player->GetEyePosition(), local->GetEyePosition(), eye_pos);

	if (Render::TransformScreen(player->GetOrigin(), pos_enemy))
	{
		if (GUI.GetMouse().x < pos_enemy.x)
			return (eye_pos.y - 90);
		else if (GUI.GetMouse().x > pos_enemy.x)
			return (eye_pos.y + 90);
	}

}

#define M_PI 3.14159265358979323846
void VectorAnglesBrute(const Vector& forward, Vector &angles)
{
	float tmp, yaw, pitch;
	if (forward[1] == 0 && forward[0] == 0)
	{
		yaw = 0;
		if (forward[2] > 0) pitch = 270; else pitch = 90;
	}
	else
	{
		yaw = (atan2(forward[1], forward[0]) * 180 / M_PI);
		if (yaw < 0) yaw += 360; tmp = sqrt(forward[0] * forward[0] + forward[1] * forward[1]); pitch = (atan2(-forward[2], tmp) * 180 / M_PI);
		if (pitch < 0) pitch += 360;
	} angles[0] = pitch; angles[1] = yaw; angles[2] = 0;
}

Vector calc_angle_trash(Vector src, Vector dst)
{
	Vector ret;
	VectorAnglesBrute(dst - src, ret);
	return ret;
}

bool playerStoppedMoving(IClientEntity* pEntity)
{
	for (int w = 0; w < 13; w++)
	{
		AnimationLayer currentLayer = pEntity->GetAnimOverlays()[1];
		const int activity = pEntity->GetSequenceActivity(currentLayer.m_nSequence);
		float flcycle = currentLayer.m_flCycle, flprevcycle = currentLayer.m_flPrevCycle, flweight = currentLayer.m_flWeight, flweightdatarate = currentLayer.m_flWeightDeltaRate;
		uint32_t norder = currentLayer.m_nOrder;
		if (activity == ACT_CSGO_IDLE_ADJUST_STOPPEDMOVING)
			return true;
	}
	return false;
}

int IClientEntity::GetSequenceActivity(int sequence)
{
	auto hdr = Interfaces::ModelInfo->GetStudiomodel(this->GetModel());

	if (!hdr)
		return -1;

	static auto getSequenceActivity = (DWORD)(Utilities::Memory::FindPatternV2("client_panorama.dll", "55 8B EC 83 7D 08 FF 56 8B F1 74"));
	static auto GetSequenceActivity = reinterpret_cast<int(__fastcall*)(void*, studiohdr_t*, int)>(getSequenceActivity);

	return GetSequenceActivity(this, hdr, sequence);
}
/*
float resolver_helper::anti_freestanding_left(IClientEntity* player)
{
const auto local = hackManager.pLocal();

if (!local)
return -1;

if (!Options::Menu.RageBotTab.apply_freestanding.GetState())
return -1;

auto atme = calc_angle_trash(player->GetEyePosition(), local->GetEyePosition());

Vector direction_1;

AngleVectors(Vector(0.f, calc_angle_trash(local->m_VecORIGIN(), player->m_VecORIGIN()).y - 90.f, 0.f), &direction_1);

const auto left_eye_pos = player->m_VecORIGIN() + Vector(0, 0, 64) + (direction_1 * 16.f);


anti_freestanding_damage_left = new_autowall->calculate_return_info(local->GetEyePosition(), left_eye_pos, local, player, 1).m_damage;


Ray_t ray;
trace_t trace;
CTraceWorldOnly filter;

ray.Init_2(left_eye_pos, local->GetEyePosition());
Interfaces::Trace->TraceRay(ray, MASK_ALL, &filter, &trace);
anti_freestanding_fraction_left = trace.fraction;

return anti_freestanding_damage_left;

}


float resolver_helper::anti_freestanding_right(IClientEntity* player)
{
const auto local = hackManager.pLocal();

if (!Options::Menu.RageBotTab.apply_freestanding.GetState())
return -1;

Vector direction_2;

AngleVectors(Vector(0.f, calc_angle_trash(local->m_VecORIGIN(), player->m_VecORIGIN()).y + 90.f, 0.f), &direction_2);

const auto right_eye_pos = player->m_VecORIGIN() + Vector(0, 0, 64) + (direction_2 * 16.f);

anti_freestanding_damage_right = new_autowall->calculate_return_info(local->GetEyePosition(), right_eye_pos, local, player, 1).m_damage;

Ray_t ray2;
trace_t trace2;
CTraceWorldOnly filter2;

ray2.Init_2(right_eye_pos, local->GetEyePosition());
Interfaces::Trace->TraceRay(ray2, MASK_ALL, &filter2, &trace2);
anti_freestanding_fraction_right = trace2.fraction;

return anti_freestanding_damage_right;
}

//yeah yeah so basically i tried to do it in a mega simple way but it kept overflowing or freezing so i pasted, but this time, let's change it my way.

float resolver_helper::result(IClientEntity * player)
{
const auto local = hackManager.pLocal();

if (local != nullptr)
{
auto atme = calc_angle_trash(player->m_VecORIGIN(), local->m_VecORIGIN()).y;

if (anti_freestanding_left(player) < 1 && anti_freestanding_right(player) < 1)
{
return atme; // backwards
}

else if (anti_freestanding_left(player) > anti_freestanding_right(player))
{
return atme - 75; // right
}


else if (anti_freestanding_right(player) > anti_freestanding_left(player) )
{
return atme + 75; // left
}

else
{
return player->GetLowerBodyYaw() - 120;
}
}
}

float resolver_helper::apply_freestanding(IClientEntity * player)
{
const auto local = hackManager.pLocal();

if (!player || player->IsDormant())
return -1;

const float height = 64;

if (local != nullptr)
{

if (!Options::Menu.RageBotTab.apply_freestanding.GetState())
return player->GetLowerBodyYaw() - 120;

if (!player->IsDormant() && local != player && player->GetTeamNum() != local->GetTeamNum() && !player->IsImmune())
{
return result(player);
}
}

}
*/

bool IsAdjustingBalance(IClientEntity* player, AnimationLayer *layer)
{
	for (int i = 0; i < 15; i++)
	{
		const int activity = player->GetSequenceActivity(layer[i].m_nSequence);
		if (activity == 979)
		{
			return true;
		}
	}
	return false;
}

bool adjusting_stop(IClientEntity* player, AnimationLayer *layer)
{
	for (int i = 0; i < 15; i++)
	{
		for (int s = 0; s < 14; s++)
		{
			auto anim_layer = player->GetAnimOverlay(s);
			if (!anim_layer.m_pOwner)
				continue;
			const int activity = player->GetSequenceActivity(layer[i].m_nSequence);
			if (activity == 981 && anim_layer.m_flWeight == 1.f)
			{
				return true;
			}
		}
	}
	return false;
} // ACT_CSGO_FIRE_PRIMARY

float save1[64];
float save2[64];
float avgspin[64];

float __fastcall ang_dif(float a1, float a2)
{
	float val = fmodf(a1 - a2, 360.0);

	while (val < -180.0f) val += 360.0f;
	while (val >  180.0f) val -= 360.0f;

	return val;
}


void resolver_setup::Resolve(IClientEntity* pEntity, int CurrentTarget)
{

	IClientEntity* pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (Options::Menu.RageBotTab.resolver.GetIndex() > 0)
	{
		if (Options::Menu.RageBotTab.resolver.GetIndex() == 2)
		{
			float last_simtime[64] = { 0.f };
			float last_lby[64] = { 0.f };
			float last_lby_delta[64] = { 0.f };
			float large_lby_delta[64] = { 0.f };
			float moving_lby[64] = { 0.f };
			bool  was_moving[64] = { false };

			const auto local = hackManager.pLocal();
			if (!local) return;

			for (auto i = 0; i < Interfaces::Engine->GetMaxClients(); ++i)
			{
				const auto player = const_cast <IClientEntity*>(Interfaces::EntList->GetClientEntity(i));


				if (!player || local == player || player->GetTeamNum() == local->GetTeamNum() || player->IsImmune() || player->IsDormant()) {
					last_simtime[i] = 0.f;
					last_lby[i] = 0.f;
					last_lby_delta[i] = 0.f;
					large_lby_delta[i] = 0.f;
					was_moving[i] = false;
					continue;
				}

				//grab values from player
				const auto lby = player->GetLowerBodyYaw();
				const auto eye = player->GetEyeAnglesXY();
				const auto sim = player->GetSimulationTime();
				const auto vel = player->GetVelocity().Length2D();

				//auto missed = Globals::missedshots;
				auto missed = Globals::fired - Globals::hit;
				while (missed > 5) missed -= 5;
				while (missed < 0) missed += 5;

				auto is_legit = false;
				auto update = false;


				if (sim - last_simtime[i] >= 1) {
					if (sim - last_simtime[i] == 1)
					{

						is_legit = true;
					}
					last_simtime[i] = sim;
				}

				if (lby != last_lby[i])
				{
					update = true;
					auto delta = fabsf(lby - last_lby[i]);
					last_lby_delta[i] = delta;
					if (delta > 90)
					{
						large_lby_delta[i] = delta;
					}
					last_lby[i] = lby;
				}

				auto angle = 0.f;
				if (GetAsyncKeyState(Options::Menu.RageBotTab.OverrideKey.GetKey()) && vel < 60) {
					angle = override_yaw(player, local);
				}
				if (is_legit)
				{
					if (GetAsyncKeyState(Options::Menu.RageBotTab.OverrideKey.GetKey()))
					{
						angle = override_yaw(pEntity, pLocal);
					}
					else
					{
						angle = eye->y;

					}
				}
				else if (update)
				{
					if (GetAsyncKeyState(Options::Menu.RageBotTab.OverrideKey.GetKey()) && vel < 145)
					{
						angle = override_yaw(player, local);
					}
					else
					{
						angle = lby;
					}
				}

				else if (vel > 35)
				{

					angle = lby;
					moving_lby[i] = lby;
					was_moving[i] = true;
				}
				else if (was_moving[i])
				{
					if (GetAsyncKeyState(Options::Menu.RageBotTab.OverrideKey.GetKey()))
					{
						angle = override_yaw(pEntity, pLocal);
					}
					else
					{
						switch (missed)
						{
						case 0: angle = moving_lby[i]; break;
						case 1: angle = lby + large_lby_delta[i]; break;
						case 2: angle = lby + last_lby_delta[i]; break;
						case 3: angle = moving_lby[i]; break;
						case 4: angle = moving_lby[i] + 180; break;
						default: angle = lby - 120;
						}
					}
				}
				else
				{
					if (GetAsyncKeyState(Options::Menu.RageBotTab.OverrideKey.GetKey()))
					{
						angle = override_yaw(pEntity, pLocal);
					}
					else
					{
						switch (missed) {
						case 0: angle = lby - 120; break;
						case 1: angle = lby + large_lby_delta[i]; break;
						case 2: angle = lby + last_lby_delta[i]; break;
						case 3: angle = moving_lby[i] - 35; break;
						case 4: angle = moving_lby[i] + 145; break;
						default: angle = lby + (90 * (missed + 1));
						}
					}

				}


				player->GetEyeAnglesXY()->y = angle;
			}
		}

		if (Options::Menu.RageBotTab.resolver.GetIndex() == 3)
		{
			bool in_air[64] = { false };
			bool change[64] = { false };
			bool fakewalk[64] = { false };
			bool wasmoving[64] = { false };
			bool wasfakewalk[64] = { false };
			bool lowdelta[64] = { false };
			bool highdelta[64] = { false };
			bool didsync[64] = { false };
			bool spin[64] = { false };
			bool moving[64] = { false };
			bool hadmovingdif[64] = { false };
			bool hadslowlby[64] = { false };
			bool has_fake979[64] = { false };
			bool was_inair[64] = { false };
			bool did_fakewalk_change[64] = { false };

			float delta[64] = { 0.f };
			float oldlby[64] = { 0.f };
			float last_sim[64] = { 0.f };
			float last_sync[64] = { 0.f };
			float movinglby[64] = { 0.f };
			float deltaDiff[64] = { 0.f };
			float slowlby[64] = { 0.f };
			float temp_dif[64] = { 0.f };
			float movingdif[64] = { 0.f };
			float fakewalk_change[64] = { 0.f };

			static float add_time[65];

			static bool updated_once[65];
			static bool lbybreak[65];
			static bool nextflick[65];
			static bool lbybacktrack[65];

			static bool override[64];

			const auto local = hackManager.pLocal();
			if (!local) return;

		
			for (auto i = 0; i < Interfaces::Engine->GetMaxClients(); ++i)
			{
				const auto player = const_cast <IClientEntity*>(Interfaces::EntList->GetClientEntity(i));

				if (!player || local == player || player->GetTeamNum() == local->GetTeamNum() || player->IsImmune() || player->IsDormant())
				{
					wasfakewalk[i] = false;
					hadmovingdif[i] = false;
					didsync[i] = false;
					didsync[i] = false;
					change[i] = false;
					highdelta[i] = false;
					lowdelta[i] = false;
					temp_dif[i] = 0.f;
					oldlby[i] = 0.f;
					last_sim[i] = 0.f;
					continue;
				}

				auto update = false;
				auto nofake = false;

				const auto lby = player->GetLowerBodyYaw();
				const auto eye = player->GetEyeAnglesXY();
				const auto sim = player->GetSimulationTime();
				const auto speed = player->GetVelocity().Length2D();

				float lbyDelta = ang_dif(lby, save1[i]);
				float lbyDelta2 = ang_dif(save1[i], save2[i]);

				int missed[65];
				int fired[65];
				fired[i] = global_count::shots_fired[i];

				missed[i] = global_count::shots_fired[i] - global_count::hits[i];
				while (missed[i] > 3) missed[i] -= 3;
				//	while (missed[i] < 0) missed[i] += 3;

				while (fired[i] >= 3) fired[i] -= 3;

				for (int s = 0; s < 14; s++)
				{
					auto anim_layer = pEntity->GetAnimOverlay(s);
					if (!anim_layer.m_pOwner)
						continue;
					auto anime = &pEntity->GetAnimOverlays()[1];
					auto activity = GetSequenceActivity(pEntity, anime->m_nSequence);

					if (activity == -1)
						continue;

					if (sim - last_sim[i] >= 1)
					{
						if (sim - last_sim[i] == 1 && !IsAdjustingBalance(player, anime))
						{
							didsync[i] = true;
							nofake = true;
						}
						last_sim[i] = sim;
					}

					if (!(player->GetFlags() & FL_ONGROUND))
					{
						in_air[i] = true;
						was_inair[i] = true;
					}
					else
					{
						in_air[i] = false;
						if (speed >= 90.f)
						{
							hadslowlby[i] = true;
							movinglby[i] = lby;
							moving[i] = true;

							add_time[i] = 0.22f;
							nextflick[i] = sim + add_time[i];
						}
						else if (speed > 1.f && speed < 90.f)
						{
							was_inair[i] = true;
							add_time[i] = 0.22f;
							nextflick[i] = sim + add_time[i];

							if (IsAdjustingBalance(player, anime))
							{
								fakewalk[i] = true;
								wasfakewalk[i] = true;
								hadslowlby[i] = false;
								if (!wasmoving[i])
								{
									if (oldlby[i] - lby >= 60 || oldlby[i] - lby <= -60)
									{
										did_fakewalk_change[i] = true;
										fakewalk_change[i] = oldlby[i] - lby;
									}
									else
										did_fakewalk_change[i] = false;
								}
								else
								{
									if (speed < 20)
									{
										if (movinglby[i] - lby >= 60 || movinglby[i] - lby <= -60)
										{
											did_fakewalk_change[i] = true;
											fakewalk_change[i] = oldlby[i] - lby;
										}
										else
											did_fakewalk_change[i] = false;
									}
									else
										did_fakewalk_change[i] = false;
								}
							}
							else
							{
								hadslowlby[i] = true;
								moving[i] = true;
								slowlby[i] = lby;
							}
						}
						else
						{
							if (GetAsyncKeyState(Options::Menu.RageBotTab.OverrideKey.GetKey()))
							{
								override[i] = true;
							}
							else
							{
								override[i] = false;
							}

							if (!nofake && !override[i])
							{
								if (didsync[i])
									last_sync[i] = eye->y;

								if (lby != save1[i] && save1[i] != save2[i])
								{
									avgspin[i] = (lbyDelta + lbyDelta2) / 2.f;
									deltaDiff[i] = fabsf(lbyDelta - lbyDelta2);
									spin[i] = true;
								}

								if (sim >= nextflick[i] && !player->IsDormant())
								{
									lbybreak[i] = true;
									add_time[i] = 1.1f;
									nextflick[i] = sim + add_time[i];
								}
								else
								{
									lbybreak[i] = false;
									lbybacktrack[i] = false;
								}

								if (oldlby[i] != lby && !spin[i] && !player->IsDormant())
								{
									oldlby[i] = lby;

									lbybreak[i] = true;
									update = true;
									delta[i] = fabsf(lby - oldlby[i]);

									if (delta[i] < -45 || delta[i] > 45)
										change[i] = true;
									else
										change[i] = false;

									add_time[i] = Interfaces::Globals->interval_per_tick + 1.1f;
									nextflick[i] = sim + add_time[i];
								}
								else
									lbybreak[i] = false;

								if (wasmoving[i] && oldlby[i] != lby && slowlby[i] != lby)
								{
									movingdif[i] = slowlby[i] - lby;
									if (movingdif[i] <= -50 || movingdif[i] >= 50)
									{
										hadmovingdif[i] = true;
									}
								}

								if (anim_layer.m_flWeight == 0.f)
								{
									lowdelta[i];
								}

								if (anim_layer.m_flWeight == 1.f)
								{
									highdelta[i];
								}
							}
						}
					}
				}

				auto yaw = 0.f;

				if (in_air)
				{

					switch (missed[i])
					{
					case 0: yaw = lby - 60;
						break;
					case 1: yaw = lby;
						break;
					case 2: yaw = lby + 90;
						break;
					case 3: yaw = lby;
						break;
					}
				}
				else
				{
					if (moving)
					{
						yaw = lby;
					}
					else if (fakewalk)
					{
						if (wasmoving[i])
						{
							
							yaw = movinglby[i];
						}
						else
						{
							switch (missed[i])
							{
							case 0: { auto atme = calc_angle_trash(player->m_VecORIGIN(), local->m_VecORIGIN()).y; yaw = atme - 180; }
									break;
							case 1: { auto atme = calc_angle_trash(player->m_VecORIGIN(), local->m_VecORIGIN()).y; yaw = atme - 180; }
									break;
							case 2: yaw = lby - 90;
								break;
							case 3: yaw = lby + 15;
								break;
							}

						}
					}
					else if (speed < 90.f && !fakewalk && speed > 1.f)
					{
						if (wasmoving[i])
						{
							if (did_fakewalk_change[i])
							{
								switch (fired[i])
								{
								case 0: yaw = movinglby[i];
									break;
								case 1: { auto atme = calc_angle_trash(player->m_VecORIGIN(), local->m_VecORIGIN()).y;
									yaw = atme - 160; }
										break;
								case 2: { auto atme = calc_angle_trash(player->m_VecORIGIN(), local->m_VecORIGIN()).y;
									yaw = atme + 160; }
										break;
										break;
								case 3: yaw = movinglby[i];
									break;
								}
							}
							else
							{
								switch (missed[i])
								{
								case 0: yaw = movinglby[i];
									break;
								case 1: { auto atme = calc_angle_trash(player->m_VecORIGIN(), local->m_VecORIGIN()).y;
									yaw = atme - 160; }
										break;
								case 2: { auto atme = calc_angle_trash(player->m_VecORIGIN(), local->m_VecORIGIN()).y;
									yaw = atme + 160; }
										break;
								case 3: yaw = movinglby[i];
									break;
								}
							}
						}
						else
						{
							yaw = lby;
						}
					}
					else if (speed <= 1.f)
					{
						if (lbybreak[i] && !player->IsDormant())
						{
							yaw = lby;
						}
						else if (!lbybreak[i])
						{
							if (nofake)
							{
								yaw = eye->y;
							}
							else if (GetAsyncKeyState(Options::Menu.RageBotTab.OverrideKey.GetKey()))
							{
								yaw = override_yaw(player, local);
							}
							else if (change[i] && wasmoving[i])
							{
								if (hadmovingdif)
								{
									switch (missed[i])
									{
									case 0: yaw = movinglby[i];
										break;
									case 1: yaw = movinglby[i] - 15;
										break;
									case 2: yaw = movinglby[i];
										break;
									case 3: yaw = lby - movingdif[i];
										break;
									}
								}
								else
								{
									switch (missed[i])
									{
									case 0: yaw = movinglby[i];
										break;
									case 1: yaw = movinglby[i] - 15;
										break;
									case 2: yaw = lby - delta[i];
										break;
									case 3: yaw = movinglby[i];
										break;
									}
								}
							}
							else if (change[i] && !wasmoving[i])
							{

								switch (missed[i])
								{
								case 0: yaw = lby - delta[i];
									break;
								case 1: yaw = lby - delta[i] + 15;
									break;
								case 2: yaw = lby - delta[i];
									break;
								case 3: yaw = lby - delta[i] - 15;
									break;
								}
							}
							else
							{
								if (highdelta[i] && !spin && !wasmoving[i] && !change[i] && !was_inair[i])
								{

									switch (missed[i])
									{
									case 0: yaw = lby - 120;
										break;
									case 1: yaw = lby - 160;
										break;
									case 2: yaw = lby - 135;
										break;
									case 3: yaw = lby - 90;
										break;
									}
								}
								else if (lowdelta[i] && !didsync[i] && !wasmoving[i] && !change[i] && !spin[i])
								{
									switch (missed[i])
									{
									case 0: yaw = lby - 90;
										break;
									case 1: yaw = lby - 110;
										break;
									case 2: yaw = lby - 30;
										break;
									case 3: yaw = lby - 60;
										break;
									}
								}
								else
								{
									if (!nofake && didsync[i] && (lby - last_sync[i] <= -35.f || lby - last_sync[i] >= 35.f) && !spin[i] && !change[i])
									{
										switch (missed[i])
										{
										case 0: yaw = last_sync[i];
											break;
										case 1: yaw = last_sync[i] - 45;
											break;
										case 2: yaw = last_sync[i];
											break;
										case 3: yaw = last_sync[i] + 45;
											break;
										}
									}
									else
									{
										switch (fired[i])
										{
										case 0: yaw = lby - 60;
											break;
										case 1: yaw = lby;
											break;
										case 2: yaw = lby - 120;
											break;
										case 3: yaw = lby - 35;
											break;
										}
									}
								}
							}
						}
						else
						{
							switch (missed[i])
							{
							case 0: yaw = lby;
								break;
							case 1: yaw = lby - 20;
								break;
							case 2: yaw = lby + 20;
								break;
							case 3: yaw = lby;
								break;
							}
						}
					}
				}
				player->GetEyeAnglesXY()->y = yaw;

			}
		}
		if (Options::Menu.RageBotTab.resolver.GetIndex() == 4)
		{
			//	pEntity->GetEyeAnglesXY()->y =resolver_help->apply_freestanding(pEntity);
		}
		if (Options::Menu.RageBotTab.resolver.GetIndex() == 1)
		{

			bool in_air[64] = { false };
			bool change[64] = { false };
			bool fakewalk[64] = { false };
			bool wasmoving[64] = { false };
			bool wasfakewalk[64] = { false };
			bool lowdelta[64] = { false };
			bool highdelta[64] = { false };
			bool didsync[64] = { false };
			bool spin[64] = { false };
			bool moving[64] = { false };
			bool hadmovingdif[64] = { false };
			bool hadslowlby[64] = { false };
			bool has_fake979[64] = { false };
			bool was_inair[64] = { false };
			bool did_fakewalk_change[64] = { false };
			bool prebreak[64] = { false };
			bool was_stopping[64] = { false };
			bool did_shoot[64] = { false };
			bool nofake[64] = { false };

			float delta[64] = { 0.f };
			float oldlby[64] = { 0.f };
			float last_sim[64] = { 0.f };
			float last_sync[64] = { 0.f };
			float movinglby[64] = { 0.f };
			float deltaDiff[64] = { 0.f };
			float slowlby[64] = { 0.f };
			float movingdif[64] = { 0.f };
			float fakewalk_change[64] = { 0.f };
			float last_forced_shot[64] = { 0.0f };
			float stand_lby[64] = { 0.0f };

			static float add_time[64];

			static bool updated_once[64];
			static bool lbybreak[64];
			static bool nextflick[64];
			static bool lbybacktrack[64];
			static bool is_stopping[64];
			static bool freestanding_left[64];
			static bool freestanding_right[64];
			static bool freestanding_back[64];
			static bool should_do_freestanding[64];
			static bool balance[64];

			static bool angle_override[64];

			const auto local = hackManager.pLocal();

			if (!local)
				return;

			for (auto i = 0; i < Interfaces::Engine->GetMaxClients(); ++i)
			{
				const auto player = const_cast <IClientEntity*>(Interfaces::EntList->GetClientEntity(i));

				if (!player || local == player || player->GetTeamNum() == local->GetTeamNum() || player->IsImmune() || player->IsDormant())
				{
					wasfakewalk[i] = false;
					hadmovingdif[i] = false;
					didsync[i] = false;
					didsync[i] = false;
					change[i] = false;
					highdelta[i] = false;
					lowdelta[i] = false;
					prebreak[i] = false;
					is_stopping[i] = false;
					was_stopping[i] = false;
					should_do_freestanding[i] = false;
					oldlby[i] = 0.f;
					last_sim[i] = 0.f;
					last_forced_shot[i] = 0.f;
					stand_lby[i] = false;
					nofake[i] = false;
					continue;
				}

				auto update = false;

				const auto lby = player->GetLowerBodyYaw();
				const auto eye = player->GetEyeAnglesXY();
				const auto sim = player->GetSimulationTime();
				const auto speed = player->GetVelocity().Length2D();

				float lbyDelta = ang_dif(lby, save1[i]);
				float lbyDelta2 = ang_dif(save1[i], save2[i]);

				int missed[65];
				int fired[65];
				fired[i] = global_count::shots_fired[i];

				missed[i] = global_count::shots_fired[i] - global_count::hits[i];
				while (missed[i] > 3) missed[i] -= 3;
				//	while (missed[i] < 0) missed[i] += 3;

				while (fired[i] >= 3) fired[i] -= 3;

				for (int s = 0; s < 14; s++)
				{
					auto anim_layer = pEntity->GetAnimOverlay(s);
					if (!anim_layer.m_pOwner)
						continue;
					auto anime = &pEntity->GetAnimOverlays()[1];
					auto activity = GetSequenceActivity(pEntity, anime->m_nSequence);

					if (activity == -1)
						continue;

					if (sim - last_sim[i] >= 1)
					{
						if (sim - last_sim[i] == 1 && !IsAdjustingBalance(player, anime))
						{
							didsync[i] = true;
							nofake[i] = true;
						}
						last_sim[i] = sim;
					}
					// this is a legit check justin. I know this was too hard for you to understand on stream, but this is what a legit check looks like.
					// I don't know how "nofake" didn't send off alarms in your head telling you what this is meant to be, but oh well, what do i know huh

					if (GetAsyncKeyState(Options::Menu.RageBotTab.OverrideKey.GetKey()) && (player->GetFlags() & FL_ONGROUND) && speed < 90.f)
					{
						angle_override[i] = true;
					}
					else
					{
						angle_override[i] = false;
					}

					if (!(player->GetFlags() & FL_ONGROUND))
					{
						in_air[i] = true;
						was_inair[i] = true;
					}
					else
					{
						in_air[i] = false;
						if (speed >= 90.f)
						{
							movinglby[i] = lby;
							was_stopping[i] = false;
							moving[i] = true;
							add_time[i] = 0.22f;
							nextflick[i] = sim + add_time[i];
						}
						else if (speed > 0.1f && speed < 90.f)
						{
							add_time[i] = 0.22f;
							nextflick[i] = sim + add_time[i];

							if (IsAdjustingBalance(player, anime))
							{
								fakewalk[i] = true;
								wasfakewalk[i] = true;
								hadslowlby[i] = false;
								if (oldlby[i] - lby >= 60 || oldlby[i] - lby <= -60)
								{
									did_fakewalk_change[i] = true;
									fakewalk_change[i] = oldlby[i] - lby;
								}
								else
									did_fakewalk_change[i] = false;

								if (adjusting_stop(player, anime))
								{
									is_stopping[i] = true;
									was_stopping[i] = true;

									if (wasmoving[i])
										deltaDiff[i] = lby - movinglby[i];
									else
									{
										if (hadslowlby[i])
											deltaDiff[i] = lby - slowlby[i];
										else
										{
											if (stand_lby[i] != 0.0f)
											{
												deltaDiff[i] = lby - stand_lby[i];
											}
										}
									}
								}
								else
									is_stopping[i] = false;


								if (oldlby[i] != lby)
								{
									deltaDiff[i] = oldlby[i] - lby;
									oldlby[i] = lby;
								}
							}
							else
							{
								did_shoot[i] = false;
								hadslowlby[i] = true;
								moving[i] = true;
								slowlby[i] = lby;
							}
						}
						else
						{
							if (!nofake && !(GetAsyncKeyState(Options::Menu.RageBotTab.OverrideKey.GetKey())))
							{
								if (didsync[i])
									last_sync[i] = eye->y;

								stand_lby[i] = lby;

								if (fabs(last_sim[i] - sim) > 2.0f && speed < 0.1f)
								{
									last_sim[i] = 0.f;
									last_forced_shot[i] = 0.0f;
								}

								if (fabsf(last_forced_shot[i] - sim) > 0.1f && speed < 0.1f)
								{
									last_forced_shot[i] = sim;
									did_shoot[i] = true;
								} // dasmax codenz <3
								else
								{
									did_shoot[i] = false;
								}

								if (oldlby[i] != lby && !spin[i])
								{
									oldlby[i] = lby;
									update = true;

									change[i] = true;
									add_time[i] = Interfaces::Globals->interval_per_tick + 1.1f;
									nextflick[i] = sim + add_time[i];

									if (IsAdjustingBalance(player, anime) && fabsf(lby - oldlby[i]) < 120 && anim_layer.m_flWeight == 0.f && !wasmoving[i])
									{
										delta[i] = fabsf(lby - oldlby[i]) - 35;
									}

									else
									{
										delta[i] = fabsf(lby - oldlby[i]);
									}
								}
								else
								{
									lbybreak[i] = false;
								}

								if (sim >= nextflick[i])
								{
									lbybreak[i] = true;
									add_time[i] = 1.1f;
									nextflick[i] = sim + add_time[i];
								}
								else
								{
									lbybreak[i] = false;
									lbybacktrack[i] = false;
								}

								if (!wasmoving[i])
								{

									if (anim_layer.m_flWeight == 1.f && IsAdjustingBalance(player, anime))
									{
										highdelta[i] = true;
										lowdelta[i] = false;
										prebreak[i] = false;
									}

									else if (anim_layer.m_flWeight == 1.f && IsAdjustingBalance(player, anime))
									{
										highdelta[i] = false;
										lowdelta[i] = false;
										prebreak[i] = true;
									}

									else if (anim_layer.m_flWeight == 0.f && !IsAdjustingBalance(player, anime))
									{
										highdelta[i] = false;
										lowdelta[i] = true;
										prebreak[i] = false;
									}

									else if ((anim_layer.m_flWeight == 0.f && IsAdjustingBalance(player, anime)) || (change[i] && delta[i] < 120 && IsAdjustingBalance(player, anime)) || did_shoot[i])
									{
										highdelta[i] = false;
										lowdelta[i] = false;
										prebreak[i] = true;
									}

									else
									{
										highdelta[i] = false;
										lowdelta[i] = false;
										prebreak[i] = false;
									}


								}
							}
						}
					}
				}

				//------------------- Resolve -------------------//

				auto yaw = 0.f;

				if (GetAsyncKeyState(Options::Menu.RageBotTab.OverrideKey.GetKey()))
				{
					yaw = override_yaw(player, local);
				}

				if (in_air)
				{
					yaw = lby - (45 * fired[i] + 1);
				}
				else
				{
					if (moving)
					{
						yaw = lby;
					}
					else if (speed > 0.1f && speed < 90.f)
					{
						if (fakewalk)
						{
							if (wasmoving[i] && !hadslowlby[i])
							{
								if (fired[i] < 2)
									yaw = movinglby[i];
								else
								{
									yaw = lby;
								}

							}
							else if (wasmoving[i] && hadslowlby[i])
							{
								if (fired[i] < 2)
									yaw = movinglby[i];
								else
									yaw = slowlby[i];
							}
							else if (!wasmoving[i] && hadslowlby[i])
							{
								if (fired[i] < 2)
									yaw = slowlby[i];
								else
								{
									yaw = lby;
								}
							}
							else
							{
								yaw = lby;
							}
						}
						else
						{
							yaw = lby;
						}
					}
					else
					{
						if (lbybreak[i] || update) // :elephant: 
						{
							yaw = lby;
						}
						else if (!lbybreak[i] && !nofake[i])
						{
							// ------------ movement related things ------------ //

							if (wasmoving[i] && !wasfakewalk[i])
							{
								if (fired[i] < 2)
									yaw = movinglby[i];
								else
									yaw = slowlby[i];
							}

							else if (!wasmoving[i] && !wasfakewalk[i] && hadslowlby[i] && !change[i])
							{
								if (fired[i] < 2)
									yaw = slowlby[i];
								else
									lby;
							}

							else if (!wasmoving[i] && !wasfakewalk[i] && hadslowlby[i] && change[i])
							{
								if (fired[i] < 2)
									yaw = slowlby[i];
								else
									yaw = lby - delta[i];
							}

							else if (!wasmoving[i] && wasfakewalk[i] && hadslowlby[i] && !change[i])
							{
								if (fired[i] < 2)
									yaw = slowlby[i];
								else
								{
									yaw = lby - (20 * fired[i]);
								}
							}

							else if (!wasmoving[i] && wasfakewalk[i] && !hadslowlby[i] && change[i])
							{
								if (fired[i] < 2)
								{
									yaw = lby - deltaDiff[i];
								}
								else
									yaw = lby - (deltaDiff[i] * fired[i]);
							}

							else if (!wasmoving[i] && wasfakewalk[i] && !hadslowlby[i] && !change[i])
							{
								if (deltaDiff[i] > 35 || deltaDiff[i] < 35)
								{
									if (fired[i] < 2)
										yaw = lby - deltaDiff[i];
									else
									{
										yaw = lby - (90 * fired[i]);

									}
								}
								else
								{
									if (fired[i] < 2)
									{
										yaw = lby;
									}
									else
									{
										yaw = lby - (60 * fired[i]);
									}
								}
							}

							// ------------ standing related things ------------ //

							else if (!wasmoving[i] && !wasfakewalk[i] && !hadslowlby[i])
							{
								if (prebreak[i]) // if they did 979, but their delta < 120
								{
									if (fired[i] <= 2)
									{
										yaw = lby - (120 * fired[i] + 1);
									}
									else
										yaw = lby - delta[i] - (15 * fired[i]);
								}

								else if (lowdelta[i] && !change[i]) // if we did not see their lby change, but are balancing weight.
								{
									if (fired[i] < 2)
										yaw = lby - (60 * fired[i] + 1);
									else
									{
										yaw = lby + (35 * fired[i]);
									}
								}

								else if (lowdelta[i] && change[i]) // if we saw their lby change and can grab delta
								{
									if (fired[i] < 2)
										yaw = lby - delta[i];
									else
										yaw = lby - (75 * missed[i]);
								}

								else if (highdelta[i] && !change[i])
								{
									if (fired[i] < 1)
										yaw = lby - 135;
									else
									{

										yaw = lby - (120 * fired[i]); // backwards
									}
								}

								else if (highdelta[i] && change[i])
								{
									if (fired[i] < 2)
										yaw = lby - delta[i];
									else
									{
										yaw = lby - (delta[i] * fired[i]);
									}
								}

								else if (change[i] && !highdelta[i] && !lowdelta[i] && !prebreak[i]) // just be sure
								{
									if (fired[i] < 2)
										yaw = lby - delta[i];
									else
										yaw = lby - delta[i] - (20 * fired[i]); // so if the delta is 90, it will be 90 - (20 x2, then 3) which is 40 and 60.
								}

								else if (!highdelta[i] && !change[i] && !prebreak[i] && !lowdelta[i])
								{
									if (fired[i] < 2)
										yaw = lby;
									else
									{
										yaw = lby - 120;
									}
								}
								else
									yaw = lby;
							}
							else
								yaw = lby;
						}

						if (nofake[i])
						{
							yaw = eye->y;
						}
					}
				}
				player->GetEyeAnglesXY()->y = yaw;
			}
		}

	}

	if (Options::Menu.LegitBotTab.legitresolver.GetIndex() == 1 && Options::Menu.RageBotTab.resolver.GetIndex() < 1)
	{
		const auto local = hackManager.pLocal();
		auto legit = false;

		bool did_change[64] = { false };
		float last_lby[64] = { 0.f };
		float difference[64] = { 0.f };
		float moving_lby[64] = { 0.f };
		float last_simtime[64] = { 0.f };
		bool  was_moving[64] = { false };

		if (!local) return;


		for (auto i = 0; i < Interfaces::Engine->GetMaxClients(); ++i)
		{
			const auto player = const_cast <IClientEntity*>(Interfaces::EntList->GetClientEntity(i));

			if (!player || local == player || player->GetTeamNum() == local->GetTeamNum() || player->IsImmune() || player->IsDormant()) {
				last_simtime[i] = 0.f;
				difference[i] = 0.f;
				last_lby[i] = 0.f;
				did_change[i] = false;
				was_moving[i] = false;
				continue;
			}


			const auto lby = player->GetLowerBodyYaw();
			const auto eye = player->GetEyeAnglesXY();
			const auto sim = player->GetSimulationTime();
			const auto vel = player->GetVelocity().Length2D();

			auto missed = Globals::fired - Globals::hit;
			while (missed > 3) missed -= 3;
			while (missed < 0) missed += 3;


			if (sim - last_simtime[i] >= 1)
			{
				if (sim - last_simtime[i] == 1)
				{
					legit = true;
				}
				else
				{
					legit = false;
				}
				last_simtime[i] = sim;
			}

			if (last_lby[i] != lby && fabsf(lby - last_lby[i]) > 35 && vel < 1 && !legit)
			{
				did_change[i] = true;
				difference[i] = fabsf(lby - last_lby[i]);
			}

			auto angle = 0.f;

			if (!(pLocal->GetFlags() % FL_ONGROUND))
			{
				if (legit)
					angle = eye->y;
				else
				{
					switch (missed % 3)
					{
					case 0: angle = lby;
						break;
					case 1: angle = lby - 90;
						break;
					case 2: angle = lby - 180;
						break;
					}
				}
			}
			else
			{
				if (vel > 1)
				{
					was_moving[i] = true;
					moving_lby[i] = lby;
					angle = lby;
				}
				else
				{
					if (legit)
						angle = eye->y;
					else
					{
						if (was_moving[i])
						{
							if (did_change[i])
							{
								switch (missed % 3)
								{
								case 0: angle = moving_lby[i];
									break;
								case 1: angle = lby - difference[i];
									break;
								case 2: angle = moving_lby[i];
									break;
								}
							}
							else
							{
								switch (missed % 3)
								{
								case 0: angle = moving_lby[i];
									break;
								case 1: angle = lby;
									break;
								case 2: angle = moving_lby[i] - 15;
									break;
								}
							}
						}
						else
						{
							if (did_change[i])
							{
								switch (missed % 3)
								{
								case 0: angle = lby - difference[i];
									break;
								case 1: angle = lby - difference[i] + 15;
									break;
								case 2: angle = lby;
									break;
								}
							}
							else
							{
								switch (missed % 3)
								{
								case 0: angle = lby - 45;
									break;
								case 1: angle = lby - 90;
									break;
								case 2: angle = lby;
									break;
								}
							}
						}
					}
				}
			}
			player->GetEyeAnglesXY()->y = angle;


		}


	}


}


/*

void resolver_setup::CM(IClientEntity* pEntity)
{
for (int x = 1; x < Interfaces::Engine->GetMaxClients(); x++)
{
pEntity = (IClientEntity*)Interfaces::EntList->GetClientEntity(x);
if (!pEntity
|| pEntity == hackManager.pLocal()
|| pEntity->IsDormant()
|| !pEntity->IsAlive())
continue;

}
}

*/

void resolver_setup::FSN(IClientEntity* pEntity, ClientFrameStage_t stage)
{
	if (stage == ClientFrameStage_t::FRAME_NET_UPDATE_POSTDATAUPDATE_START)
	{
		for (int i = 1; i < Interfaces::Engine->GetMaxClients(); i++)
		{

			pEntity = (IClientEntity*)Interfaces::EntList->GetClientEntity(i);

			if (!pEntity || pEntity == hackManager.pLocal() || pEntity->IsDormant() || !pEntity->IsAlive())
				continue;

			resolver_setup::Resolve(pEntity, stage);
			resolver_setup::preso(pEntity);
		}
	}
}


