#pragma once
//way shorter but still same effect lol
#include "SDK.h"

void start_prediction(CUserCmd* pCmd);