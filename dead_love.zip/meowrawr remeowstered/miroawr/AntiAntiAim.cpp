#include "Interfaces.h"
#include "Menu.h"
#include "Proxies.h"
#include "Skins.h"

RecvVarProxyFn oRecvnModelIndex;
